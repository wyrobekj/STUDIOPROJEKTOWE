package pl.zachara.studio;

/**
 * Created by user on 12.03.2017.
 * The purpose of this class is to include all attributes that we need from an Edge:
 * maxEnergy - maximum energy that can be sent through this connection
 * transferEfficiency - in percentage terms, how much of energy that was sent is delivered
 * name - each Edge has name to facilitate understanding
 */
public class ObjectEdge {
    private String name;
    private double maxEnergyTransfer;
    private double transferEfficiency;
    private double energyTransferAvailable;

    public ObjectEdge(String name, double maxEnergy, double transferEfficiency) {
        this.name = name;
        this.maxEnergyTransfer = maxEnergy;
        this.transferEfficiency = transferEfficiency;
        this.energyTransferAvailable = maxEnergy;
    }

    public ObjectEdge(String name) {
        this.name = name;
        this.maxEnergyTransfer = (double)0;
        this.transferEfficiency = (double)0;
        this.energyTransferAvailable = (double)0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getEnergyTransferAvailable() {
        return energyTransferAvailable;
    }

    public void setEnergyTransferAvailable(double energyTransferAvailable) {
        this.energyTransferAvailable = energyTransferAvailable;
    }

    public double getMaxEnergyTransfer() {
        return maxEnergyTransfer;
    }

    public void setMaxEnergyTransfer(double maxEnergyTransfer) {
        this.maxEnergyTransfer = maxEnergyTransfer;
    }

    public double getTransferEfficiency() {
        return transferEfficiency;
    }

    public void setTransferEfficiency(double transferEfficiency) {
        this.transferEfficiency = transferEfficiency;
    }
}
