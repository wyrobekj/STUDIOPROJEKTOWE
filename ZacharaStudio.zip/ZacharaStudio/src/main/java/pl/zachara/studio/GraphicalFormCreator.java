package pl.zachara.studio;

import name.zachara.utils.graphs.Edge;
import name.zachara.utils.graphs.Graph;
import name.zachara.utils.graphs.Node;
import name.zachara.utils.visuals.*;

import static name.zachara.utils.visuals.StyledNode.Color.BLACK;
import static name.zachara.utils.visuals.StyledNode.Color.YELLOW;

/**
 * Created by user on 15.03.2017.
 *  HashMap<Node, Node> nodeMap = new HashMap<Node, Node>();
 StyledGraph sg = new StyledGraph();
 Graph graph;

 void Rysujemy() {
 for (Node n : graph.getAllNodes()) {
 StyledNode.Color nodeColor = RED;
 String nodeName = "My node";
 Node nNode = sg.addNode(new StyledNode(nodeName, nodeColor));
 nodeMap.put(n, nNode);
 }

 // copy edges
 for (Edge e : graph.getAllEdges()) {
 sg.addEdge(null, nodeMap.get(e.getFromNode()), nodeMap.get(e.getToNode()));
 }

 GraphProperties gp = new GraphProperties();
 gp.setEdgeLables(GraphProperties.EdgesDisplay.LABEL);
 gp.setEdgeStyle(true, 1, new StyledNode.Color(0, 0x80, 0xff));

 BasicGraph display = new BasicGraph(crawler.buildStyledGraph(g), gp);
 */

public class GraphicalFormCreator{
    private StyledGraph visualGraph;
    private GraphExtended graph;

    public GraphicalFormCreator(GraphExtended _graph) {
        graph = _graph;
        visualGraph = new StyledGraph();
    }

    public void addNodes(){
        Node[] nodes = graph.getAllNodes();

        for(Node n: nodes){
            String text = ((ObjectNode)(n.getObject())).getName();
            String maxProd = String.valueOf(((ObjectNode)(n.getObject())).getMaxEnergyProduction());
            String maxCons = String.valueOf(((ObjectNode)(n.getObject())).getMaxEnergyConsumption());
            String name = text.concat(" ").concat(maxProd).concat(" ").concat(maxCons);
            StyledNode sn = new StyledNode(name, YELLOW);
            visualGraph.addNode(sn);
        }
    }

    public void addEdges()
    {
        Edge[] edges = graph.getAllEdges();

        for(Edge e: edges){
            String text = ((ObjectNode)(e.getObject())).getName();
            String maxEnTra = String.valueOf(((ObjectEdge)(e.getObject())).getMaxEnergyTransfer());
            String trEff = String.valueOf(((ObjectEdge)(e.getObject())).getTransferEfficiency());
            String name = text.concat(" ").concat(maxEnTra).concat(" ").concat(trEff);
            Node from = (Node) e.getFromNode();
            Node to = (Node) e.getToNode();
            visualGraph.addEdge(name, from, to);
            from.addOutgoingEdge(e);
            to.addIncomingEdge(e);

        }
    }

    public void makeGraphicalGraph(){
        addNodes();
        addEdges();
    }

    public void draw(){
        GraphProperties properties = new GraphProperties();
        StyledGraph bg = new StyledGraph();

    }

    public void doMagic()
    {
        makeGraphicalGraph();
        draw();
    }

}
