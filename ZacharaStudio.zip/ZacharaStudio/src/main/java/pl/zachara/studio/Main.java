package pl.zachara.studio;

import name.zachara.utils.graphs.Edge;
import name.zachara.utils.graphs.Node;
import name.zachara.utils.visuals.BasicGraph;
import name.zachara.utils.visuals.GraphProperties;
import name.zachara.utils.visuals.StyledGraph;
import name.zachara.utils.visuals.StyledNode;

import java.awt.*;
import java.io.FileNotFoundException;
import java.util.HashMap;

import static name.zachara.utils.visuals.StyledNode.Color.RED;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        //creation of a graph
	    GraphExtended graph = new GraphExtended();
	    //creation of an instance of a class which contains a method that populates the graph with nodes and edges
        //this class reads files "edges.txt" and "nodes.txt"
        graph.populateGraph();

        HashMap<Node, Node> nodeMap = new HashMap<Node, Node>();
        StyledGraph sg = new StyledGraph();

        for (Node n: graph.getAllNodes()) {
            StyledNode.Color nodeColor = RED;
            String nodeName = "My node";
            Node nNode = sg.addNode(new StyledNode(nodeName, nodeColor));
            nodeMap.put(n, nNode);
        }

        // copy edges
        for (Edge e: graph.getAllEdges()) {
            sg.addEdge(null, nodeMap.get(e.getFromNode()), nodeMap.get(e.getToNode()));
        }

        GraphProperties gp = new GraphProperties();
        gp.setEdgeLables(GraphProperties.EdgesDisplay.LABEL);

        gp.setEdgeStyle(true, 1, new Color(0,0x80,0xff));
//TODO: DLACZEGO NIE TAK?
        BasicGraph display = new BasicGraph(sg, gp);
    }
}
