package pl.zachara.studio;

import name.zachara.utils.graphs.Edge;
import name.zachara.utils.graphs.Graph;
import name.zachara.utils.graphs.Node;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Pattern;



public class GraphExtended extends Graph
{
    //private Graph graph;


    void print()
    {
        HashMap<Node, Object> mapa = getNodeObjects();


        for(Node item: mapa.keySet())
        {
            Object temp = mapa.get(item);
            //System.out.println("Znajduję typ klasy dla temp");
            //System.out.println(temp.getClass());
            if(temp instanceof ObjectNode){
                ObjectNode n = (ObjectNode) temp;
            }
            //System.out.println(temp);
        }
    }


    public boolean nodeNameExists(String _name) {
        Node[] m = getAllNodes();
        for (Node item : m) {
            {
                if (item.getObject() instanceof ObjectNode) {
                    if (((ObjectNode) item.getObject()).getName().equals(_name)) {
                        return true;
                    }
                }

            }
        }
        return false;
    }

    public boolean edgeNameExists(String _name){
        Edge[] e = getAllEdges();
        for (Edge item : e) {
            {
                if (item.getObject() instanceof ObjectEdge) {
                    if (((ObjectEdge) item.getObject()).getName().equals(_name)) {
                        return true;
                    }
                }

            }
        }
        return false;
    }

    public Node findNodeByName(String name) {
        Node[] n = getAllNodes();
        for (Node item : n) {
            {
                if (item.getObject() instanceof ObjectNode) {
                    if (((ObjectNode) item.getObject()).getName().equals(name)) {
                        return item;
                    }
                }

            }
        }
        return null;
    }

//dodawanie nod oparte na parsowaniu pliku tekstowego
    void createNodes() throws FileNotFoundException {
        //generuję listę nod, które mogą istniec żeby nie dodac 2 razy tego samego
        HashMap<Node, Object> m = new HashMap<Node, Object>();
        m = getNodeObjects();
        File file = new File("/Users/user/IdeaProjects/ZacharaStudio/src/main/java/nodes.txt");
        Scanner input = new Scanner(file);
        while (input.hasNextLine()) {
            String nextL = input.nextLine();
            if(nextL.length()==0)
            {
                return;
            }
            String [] splited = nextL.split("\\s+");
            String name =splited[0];
            //System.out.println(name);
            Double production = Double.parseDouble(splited[1]);
            //System.out.println(production);
            Double consumption = Double.parseDouble(splited[2]);
            //System.out.println(consumption);

            if (!nodeNameExists(name)) {
                //System.out.println("Dodaję nodę");
                //tworzę objectnode dopiero jak sprawdzę, że nie ma nody na nazwie jaką sparsowano
                ObjectNode temp = new ObjectNode(name, production, consumption);
                addNode(temp);
                //System.out.println("Sprawdzam przy dodawaniu typ obiektu");
                //System.out.println(n.getObject().getClass());
            }
        }
        print();
    }


    void createEdges() throws FileNotFoundException {
        HashMap<Edge, Object> m = new HashMap<Edge, Object>();
        m = getEdgeObjects();
        File file = new File("/Users/user/IdeaProjects/ZacharaStudio/src/main/java/edges.txt");
        Scanner input = new Scanner(file);
        while(input.hasNextLine())
        {
            String nextLine = input.nextLine();
            String [] splited = nextLine.split("\\s+");
            String name =splited[0];
            //System.out.println(name);
            String from = splited[1];
            //System.out.println(from);
            String to = splited[2];
            //System.out.println(to);
            Double maxTransfer = Double.parseDouble(splited[3]);
            //System.out.println(maxTransfer);
            Double efficiency = Double.parseDouble(splited[4]);
            //System.out.println(name);
            //System.out.println(from);
            //System.out.println(to);
            //System.out.println(maxTransfer);
            //System.out.println(efficiency);


            if(!edgeNameExists(name) && nodeNameExists(from) && nodeNameExists(to) )
            {
                ObjectEdge temp = new ObjectEdge(name, maxTransfer, efficiency);
                Node r1 = findNodeByName(from);
                Node r2 = findNodeByName(to);
                //System.out.println("Znaleziono nody:");
                //System.out.println(r1);
                //System.out.println(r2);
                Edge e = new Edge(temp, r1, r2);
                r1.addOutgoingEdge(e);
                r2.addIncomingEdge(e);
            }

            if (edgeNameExists(name) )
            {
                throw new IllegalArgumentException("Próba dodania istniejącej krawędzi");
            }

            if (!nodeNameExists(from) || !nodeNameExists(to))
            {
                throw new IllegalArgumentException("Próba stworzenia krawędzi dla nieistniejącej nody");
            }
        }
    }

    void populateGraph() throws FileNotFoundException {
        createNodes();
        createEdges();
    }

}