package pl.zachara.studio;

/**
 * Created by user on 12.03.2017.
 */
public class ObjectNode {
    private String name;
    private double maxEnergyConsumption;
    private double maxEnergyProduction;

    public ObjectNode(String name, double maxEnergyProduction, double maxEnergyConsumption) {
        this.name = name;
        this.maxEnergyConsumption = maxEnergyConsumption;
        this.maxEnergyProduction = maxEnergyProduction;
    }

    public ObjectNode(String name) {
        this.name = name;
        this.maxEnergyConsumption = (double) 0;
        this.maxEnergyProduction = (double) 0;
    }

    public ObjectNode() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMaxEnergyConsumption() {
        return maxEnergyConsumption;
    }

    public void setMaxEnergyConsumption(double maxEnergyConsumption) {
        this.maxEnergyConsumption = maxEnergyConsumption;
    }

    public double getMaxEnergyProduction() {
        return maxEnergyProduction;
    }

    public void setMaxEnergyProduction(double maxEnergyProduction) {
        this.maxEnergyProduction = maxEnergyProduction;
    }

    public Boolean nodeNamesTheSame(ObjectNode n1, ObjectNode n2)
    {
        return n1.name.equals(n2.name);
    }

    public ObjectNode copy(){
        ObjectNode newN = new ObjectNode();
        newN.name = this.getName();
        newN.maxEnergyProduction=this.getMaxEnergyProduction();
        newN.maxEnergyConsumption = this.getMaxEnergyConsumption();
        return newN;
    }
}
